twitter_name = 'awTeamGreeter'

bitly_token = '43af08545510bd38a3ea02067f22a25c70b8c3de'