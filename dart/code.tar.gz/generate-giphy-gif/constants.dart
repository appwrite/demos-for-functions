class Endpoints {
  static const GIPHY_API_KEY = 'DNM6PM9qizgV2tWyXsM3fwj7HclFvetO';
  static const GIPHY_BASE_URL = 'https://api.giphy.com/v1/gifs/search';

  static const PROJECT_ID = '614f6a91480ce';
  static const APPWRITE_API_ENDPOINT = 'http://localhost:5000/v1';
  static const SECRET_KEY =
      'e35307b3e39a595d3957bebffee5b3d66f2646df921b9d789862fcbe1d7537f988c798134c85827b518e2aef8655492be7f678315d15675e38e94c26c13d2bdd875f985f5a29579a6d761ca0241faaf1fd5e704abbaadcd12e2b6de2dd6e396c9e5cac60f3dcc26d850d16e90de4afb18c8a6ff4d362d9ceed2032df79c9a567';
}
